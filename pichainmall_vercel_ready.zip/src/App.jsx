import React, { useMemo, useState } from "react";
import { motion } from "framer-motion";

const fadeUp = {
  hidden: { opacity: 0, y: 22 },
  visible: { opacity: 1, y: 0 },
};

const productSeed = [
  ["iPhone 16 Pro Max", "Apple AI Flagship", "82 PI", "Advanced Electronics", "11 in stock", "5.0", "1822", "https://images.unsplash.com/photo-1695048133142-1a20484d2569?q=80&w=1200&auto=format&fit=crop"],
  ["iPhone 16", "Next Generation Apple", "66 PI", "Electronics", "18 in stock", "4.9", "1451", "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=1200&auto=format&fit=crop"],
  ["iPhone 15 Pro Max", "1TB Titanium", "75 PI", "Electronics", "7 in stock", "4.9", "997", "https://images.unsplash.com/photo-1695048133142-1a20484d2569?q=80&w=1200&auto=format&fit=crop"],
  ["MacBook Air M3", "Ultra Thin Apple Laptop", "39 PI", "Advanced Electronics", "15 in stock", "4.9", "1188", "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?q=80&w=1200&auto=format&fit=crop"],
  ["MacBook Pro M3 Max", "16 inch Space Black", "42 PI", "Advanced Electronics", "4 in stock", "4.9", "64", "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?q=80&w=1200&auto=format&fit=crop"],
  ["iMac M3", "Apple All-in-One Desktop", "55 PI", "Advanced Electronics", "9 in stock", "4.9", "611", "https://images.unsplash.com/photo-1527443154391-507e9dc6c5cc?q=80&w=1200&auto=format&fit=crop"],
  ["iPad Pro M4", "Apple OLED Tablet", "32 PI", "Advanced Electronics", "22 in stock", "4.9", "877", "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?q=80&w=1200&auto=format&fit=crop"],
  ["Apple Vision Pro", "Spatial Computing", "55 PI", "Advanced Electronics", "3 in stock", "4.8", "36", "https://images.unsplash.com/photo-1622979135225-d2ba269cf1ac?q=80&w=1200&auto=format&fit=crop"],
  ["Apple Watch Ultra 2", "Adventure Smartwatch", "26 PI", "Advanced Electronics", "13 in stock", "4.9", "552", "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?q=80&w=1200&auto=format&fit=crop"],
  ["AirPods Max", "Premium Apple Audio", "24 PI", "Electronics", "22 in stock", "4.8", "874", "https://images.unsplash.com/photo-1546435770-a3e426bf472b?q=80&w=1200&auto=format&fit=crop"],
  ["AirPods Pro 2", "Apple Spatial Audio", "14 PI", "Electronics", "48 in stock", "4.8", "1932", "https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?q=80&w=1200&auto=format&fit=crop"],
  ["Apple TV 4K", "Premium Streaming Device", "12 PI", "Electronics", "26 in stock", "4.7", "477", "https://images.unsplash.com/photo-1593305841991-05c297ba4575?q=80&w=1200&auto=format&fit=crop"],
  ["Samsung Galaxy S25 Ultra", "Galaxy AI Ultra", "85 PI", "Advanced Electronics", "10 in stock", "5.0", "1544", "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?q=80&w=1200&auto=format&fit=crop"],
  ["Samsung Galaxy S24 Ultra", "AI Smartphone", "68 PI", "Electronics", "9 in stock", "4.8", "666", "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?q=80&w=1200&auto=format&fit=crop"],
  ["Samsung Galaxy A55", "Popular Midrange Samsung", "24 PI", "Electronics", "35 in stock", "4.8", "642", "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?q=80&w=1200&auto=format&fit=crop"],
  ["Samsung Galaxy Z Fold 6", "Premium Foldable Phone", "78 PI", "Advanced Electronics", "8 in stock", "4.9", "214", "https://images.unsplash.com/photo-1598327105666-5b89351aff97?q=80&w=1200&auto=format&fit=crop"],
  ["Samsung Galaxy Z Flip 6", "Premium Fold Phone", "58 PI", "Advanced Electronics", "14 in stock", "4.9", "966", "https://images.unsplash.com/photo-1598327105666-5b89351aff97?q=80&w=1200&auto=format&fit=crop"],
  ["Samsung Galaxy Tab S9 Ultra", "AMOLED Android Tablet", "33 PI", "Advanced Electronics", "18 in stock", "4.8", "733", "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?q=80&w=1200&auto=format&fit=crop"],
  ["Samsung Neo QLED 8K", "Premium Smart TV", "65 PI", "Advanced Electronics", "6 in stock", "4.9", "194", "https://images.unsplash.com/photo-1593784991095-a205069470b6?q=80&w=1200&auto=format&fit=crop"],
  ["Samsung Odyssey OLED G9", "49 Inch Gaming Monitor", "48 PI", "Advanced Electronics", "7 in stock", "4.9", "288", "https://images.unsplash.com/photo-1527443154391-507e9dc6c5cc?q=80&w=1200&auto=format&fit=crop"],
  ["Samsung Bespoke AI Refrigerator", "Smart AI Kitchen", "44 PI", "Advanced Electronics", "6 in stock", "4.8", "214", "https://images.unsplash.com/photo-1584568694244-14fbdf83bd30?q=80&w=1200&auto=format&fit=crop"],
  ["Samsung Galaxy Buds 3 Pro", "Premium Wireless Audio", "11 PI", "Electronics", "31 in stock", "4.8", "844", "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=1200&auto=format&fit=crop"],
  ["Samsung Galaxy Watch 6 Classic", "Premium Smartwatch", "14 PI", "Electronics", "25 in stock", "4.8", "398", "https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=1200&auto=format&fit=crop"],
  ["Samsung SmartThings Hub", "AI Smart Home Center", "9 PI", "Electronics", "37 in stock", "4.7", "298", "https://images.unsplash.com/photo-1558002038-1055907df827?q=80&w=1200&auto=format&fit=crop"],
];

const products = productSeed.map((item, index) => ({
  name: item[0],
  subtitle: item[1],
  price: item[2],
  tag: item[3],
  stock: item[4],
  rating: item[5],
  reviews: item[6],
  image: item[7],
  orders: 120 + index * 17,
  likes: 900 + index * 31,
}));

function Button({ children, variant = "primary", className = "", onClick }) {
  const base = "inline-flex items-center justify-center rounded-xl px-4 py-2 font-semibold transition active:scale-95";
  const outline = "border border-fuchsia-500/40 bg-fuchsia-500/10 text-fuchsia-100 hover:border-[#f4af47]/70 hover:bg-fuchsia-500/20";
  const primary = "bg-[#f4af47] text-black hover:bg-yellow-300";
  return <button type="button" onClick={onClick} className={[base, variant === "outline" ? outline : primary, className].join(" ")}>{children}</button>;
}

function Card({ children, className = "" }) {
  return <div className={["rounded-2xl border border-fuchsia-500/30 bg-[#080015]/90 shadow-[0_0_35px_rgba(147,51,234,0.18)] backdrop-blur-xl", className].join(" ")}>{children}</div>;
}

function ProductCard({ product }) {
  return (
    <Card className="group overflow-hidden transition hover:-translate-y-1 hover:border-[#f4af47]/70">
      <div className="relative h-44 overflow-hidden">
        <img src={product.image} alt={product.name} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#080015] via-transparent to-transparent" />
        <span className="absolute left-3 top-3 rounded-full border border-[#f4af47]/50 bg-black/70 px-3 py-1 text-[11px] font-semibold text-[#f4af47]">{product.tag}</span>
      </div>
      <div className="p-4">
        <div className="flex items-center justify-between gap-2">
          <h3 className="text-base font-semibold text-white">{product.name}</h3>
          <span className="rounded-full border border-emerald-400/40 bg-emerald-400/10 px-2 py-1 text-[10px] font-bold text-emerald-300">✔ VERIFIED</span>
        </div>
        <p className="mt-1 text-sm text-fuchsia-100/60">{product.subtitle}</p>
        <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-fuchsia-100/55">
          <span className="text-[#f4af47]">★ {product.rating}</span>
          <span>({product.reviews} reviews)</span>
          <span>•</span>
          <span>{product.stock}</span>
          <span>•</span>
          <span className="text-emerald-300">🛒 {product.orders.toLocaleString()} orders</span>
          <span>•</span>
          <span className="text-pink-300">❤ {product.likes.toLocaleString()} likes</span>
        </div>
        <div className="mt-4 flex items-center justify-between gap-3">
          <p className="text-2xl font-black text-[#f4af47]">{product.price}</p>
          <Button variant="outline" className="px-3 py-2 text-xs">π Pay With Pi</Button>
        </div>
      </div>
    </Card>
  );
}

export default function App() {
  const [query, setQuery] = useState("");
  const filteredProducts = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return products;
    return products.filter((item) => `${item.name} ${item.subtitle} ${item.tag}`.toLowerCase().includes(normalized));
  }, [query]);

  return (
    <div className="min-h-screen overflow-hidden bg-[#030008] text-white">
      <div className="pointer-events-none fixed inset-0 z-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_15%_10%,rgba(107,61,245,0.28),transparent_32%),radial-gradient(circle_at_82%_18%,rgba(244,175,71,0.16),transparent_30%),radial-gradient(circle_at_50%_90%,rgba(168,85,247,0.18),transparent_35%)]" />
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.025)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.025)_1px,transparent_1px)] bg-[size:76px_76px]" />
      </div>

      <main className="relative z-10 mx-auto max-w-7xl px-4 py-6">
        <div className="mb-4 overflow-hidden rounded-2xl border border-fuchsia-500/30 bg-[#090012]/90 py-3 shadow-[0_0_30px_rgba(168,85,247,0.15)]">
          <motion.div animate={{ x: [0, -900] }} transition={{ repeat: Infinity, duration: 18, ease: "linear" }} className="flex min-w-max gap-12 px-6 text-sm font-semibold text-[#f4af47]">
            {["BTC $104,220 ▲2.4%", "GOLD $2,430 ▲1.2%", "PI Utility Active ●", "ETH $3,820 ▲1.8%", "NASDAQ ▲0.84%", "Apple & Samsung Official Store"].map((item, index) => <span key={index}>{item}</span>)}
          </motion.div>
        </div>

        <header className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-4xl font-black">PICHAIN<span className="text-[#f4af47]">MALL</span></p>
            <p className="text-fuchsia-200/60">Premium Pi Utility Marketplace</p>
          </div>
          <div className="flex w-full max-w-3xl items-center gap-3 rounded-2xl border border-fuchsia-500/25 bg-[#080015]/80 px-5 py-3 text-fuchsia-100/60 shadow-[0_0_35px_rgba(147,51,234,0.14)]">
            <span className="text-2xl text-fuchsia-300">⌕</span>
            <input value={query} onChange={(event) => setQuery(event.target.value)} className="w-full bg-transparent outline-none placeholder:text-fuchsia-100/45" placeholder="Cari Apple, Samsung, iPhone, Galaxy, MacBook, TV..." />
          </div>
        </header>

        <section className="mb-7 grid gap-4 lg:grid-cols-[1.05fr_1fr]">
          <Card className="p-7">
            <div className="text-sm uppercase tracking-[0.18em] text-fuchsia-200/70">Pi Airdrop Rewards <span className="text-emerald-300">● Live</span></div>
            <div className="mt-4 bg-gradient-to-r from-[#fff0a8] via-[#f4af47] to-[#b56b18] bg-clip-text text-6xl font-black tracking-tight text-transparent">250.28 PI</div>
            <p className="mt-3 text-xl text-fuchsia-100/60">Estimated claim value ⓘ</p>
          </Card>
          <Card className="p-7">
            <h2 className="text-xl font-bold uppercase tracking-[0.08em] text-fuchsia-300">Realtime Notification</h2>
            <p className="mt-5 text-lg font-semibold text-white">🇸🇬 Someone from Singapore purchased iPhone 16 Pro Max</p>
            <p className="mt-3 text-sm text-emerald-300">● LIVE MARKETPLACE ACTIVITY</p>
          </Card>
        </section>

        <section>
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold tracking-wide">🔥 APPLE & SAMSUNG COLLECTION</h2>
              <p className="mt-1 text-fuchsia-300">Smartphones • Laptops • Tablets • Audio • Smart Home</p>
            </div>
            <Button variant="outline">{filteredProducts.length} Products Available</Button>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4">
            {filteredProducts.map((product, index) => (
              <motion.div key={`${product.name}-${index}`} initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} transition={{ duration: 0.45, delay: (index % 6) * 0.05 }}>
                <ProductCard product={product} />
              </motion.div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
