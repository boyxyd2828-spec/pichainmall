# PICHAINMALL Premium Website

Project React + Vite + Tailwind siap upload ke GitHub dan deploy ke Vercel.

## Jalankan lokal

```bash
npm install
npm run dev
```

## Deploy ke Vercel

1. Upload semua file ke GitHub.
2. Buka Vercel.
3. Import repository.
4. Framework preset: Vite.
5. Build command: `npm run build`.
6. Output directory: `dist`.

Catatan: versi zip ini tidak mengubah desain style utama. Ini dikemas sebagai project deploy-ready.
